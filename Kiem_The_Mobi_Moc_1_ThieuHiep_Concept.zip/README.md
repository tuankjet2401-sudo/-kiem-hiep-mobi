# Kiếm Thế Mobi — Mốc 1: Thiếu Hiệp

Concept sheet nền cho nhánh Unity 2D + Spine.

## Thiết kế
- Chibi 4–5 heads
- Cổ trang cách tân
- Tông vàng rơm / nâu gỗ / xanh lá mạ
- Pose đứng Idle
- Thiết kế hướng tới rig Spine 2D

## Các layer dự kiến
- TH_HEAD
- TH_HAIR
- TH_BODY
- TH_ARM_L
- TH_ARM_R
- TH_LEG_L
- TH_LEG_R
- TH_WEAPON
- TH_ACCESSORY

## Trạng thái
Concept Mốc 1. Chưa phải bộ PNG layer tách riêng để import Spine.
