Thiếu Hiệp chuẩn — asset placeholder. Import Spine Skeleton tại đây.
