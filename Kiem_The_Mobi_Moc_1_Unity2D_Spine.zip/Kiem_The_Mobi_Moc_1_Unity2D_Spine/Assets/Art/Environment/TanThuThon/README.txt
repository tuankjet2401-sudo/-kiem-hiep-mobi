Tân Thủ Thôn — map nền: nhà, đường, ruộng, cây, sông/cầu.
