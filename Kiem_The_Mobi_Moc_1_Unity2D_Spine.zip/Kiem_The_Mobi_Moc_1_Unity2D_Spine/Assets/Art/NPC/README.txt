10 NPC chính — asset placeholder. Mỗi NPC dùng cùng quy chuẩn rig/idle.
