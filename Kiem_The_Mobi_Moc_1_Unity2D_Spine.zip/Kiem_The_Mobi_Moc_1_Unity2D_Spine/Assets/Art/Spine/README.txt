Đặt file Spine export (.json/.skel + atlas + texture) vào đây khi có asset thật.
