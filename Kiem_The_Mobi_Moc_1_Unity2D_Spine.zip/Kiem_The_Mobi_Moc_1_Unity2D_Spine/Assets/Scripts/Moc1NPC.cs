using UnityEngine;

public class Moc1NPC : MonoBehaviour
{
    [SerializeField] private string npcName;
    [SerializeField] private string interactionId;

    public string NpcName => npcName;
    public string InteractionId => interactionId;

    public void Setup(string name, string id)
    {
        npcName = name;
        interactionId = id;
    }

    // Mốc 1: NPC chỉ cần đứng/idle.
    // Logic tương tác sẽ mở rộng ở các mốc sau.
}
