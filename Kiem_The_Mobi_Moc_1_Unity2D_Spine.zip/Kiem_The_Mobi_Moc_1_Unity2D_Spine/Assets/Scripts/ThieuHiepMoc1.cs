using UnityEngine;

public class ThieuHiepMoc1 : MonoBehaviour
{
    // Skeleton/Rig Spine sẽ được gắn vào Prefab này.
    // Mốc 1 tập trung vào trạng thái đứng/idle.
    [SerializeField] private string characterName = "Thiếu Hiệp";

    public string CharacterName => characterName;
}
