# KIẾM THẾ MOBI — MỐC 1
Unity 2D + Spine

Mục tiêu:
- 1 Thiếu Hiệp chuẩn để làm Skeleton/Rig nền.
- Tân Thủ Thôn làm map nền đồ họa.
- 10 NPC chính ở trạng thái đứng/idle.
- Chuẩn bị cấu trúc để sau này thay trang phục, tóc, vũ khí, môn phái và animation mà không dựng lại nhân vật.

10 NPC:
1. Môn Phái
2. Hoạt Động
3. Cộng Đồng
4. Xa Phu
5. Dược Sư
6. Tạp Hóa
7. Vũ Khí
8. Thợ Rèn
9. Rương
10. Nhiệm Vụ

Lưu ý:
- Thư mục Art/Spine dành cho dữ liệu Spine thật khi import vào Unity.
- Prototype HTML 4.12.x tiếp tục là nhánh thử nghiệm riêng.
