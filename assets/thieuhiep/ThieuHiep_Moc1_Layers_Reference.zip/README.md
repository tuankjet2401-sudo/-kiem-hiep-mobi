THIẾU HIỆP — MỐC 1 — LAYER REFERENCE

Nguồn: ThieuHiep_Concept_Moc1.png.
Gồm 9 ảnh tham chiếu được cắt từ khu vực “Layer tách (PNG trong suốt)”:
TH_HEAD, TH_HAIR, TH_BODY, TH_ARM_L, TH_ARM_R,
TH_LEG_L, TH_LEG_R, TH_WEAPON, TH_ACCESSORY.

Lưu ý:
Đây là bộ PNG tham chiếu được tách từ concept sheet phẳng.
Nó chưa phải source layer PNG gốc do họa sĩ xuất riêng và chưa phải bộ
Spine production-ready. Cần kiểm tra/chỉnh lại mép cắt trước khi rig Spine 2D.
